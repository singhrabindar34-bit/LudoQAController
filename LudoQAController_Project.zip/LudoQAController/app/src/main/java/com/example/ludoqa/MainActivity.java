package com.example.ludoqa;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.net.*;
import java.util.concurrent.*;
import org.json.JSONObject;

public class MainActivity extends Activity {
    LinearLayout root, list; TextView status; EditText ip; ExecutorService pool=Executors.newCachedThreadPool(); Socket socket; PrintWriter out; boolean receiver=false;
    int green=Color.rgb(40,190,95), blue=Color.rgb(65,130,220), bg=Color.rgb(17,20,25), card=Color.rgb(31,36,44);
    String[] colors={"BLUE","RED","GREEN","YELLOW"};
    @Override public void onCreate(Bundle b){super.onCreate(b); showController();}
    TextView tv(String s,int sp){ TextView t=new TextView(this); t.setText(s); t.setTextColor(Color.WHITE); t.setTextSize(sp); t.setPadding(16,10,16,10); return t; }
    GradientDrawable bg(int c,float r){GradientDrawable g=new GradientDrawable();g.setColor(c);g.setCornerRadius(r);return g;}
    Button btn(String s){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setTextSize(15);b.setAllCaps(false);b.setBackground(bg(Color.rgb(48,56,70),18));b.setPadding(4,2,4,2);return b;}
    void base(String title){ root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(bg); ScrollView sv=new ScrollView(this); list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);list.setPadding(18,12,18,30);sv.addView(list); root.addView(sv,new LinearLayout.LayoutParams(-1,0,1)); setContentView(root); TextView h=tv(title,26);h.setTypeface(null,1);h.setBackgroundColor(Color.rgb(39,44,54));h.setPadding(20,24,20,18); root.addView(h,0,new LinearLayout.LayoutParams(-1,Wrap(78))); }
    int Wrap(int x){return (int)(x*getResources().getDisplayMetrics().density/1f);}
    void showController(){receiver=false;base("Ludo QA Controller");
        status=tv("●  DISCONNECTED",17);status.setTextColor(Color.LTGRAY);status.setBackground(bg(card,22));list.addView(status,new LinearLayout.LayoutParams(-1,Wrap(52)));
        LinearLayout con=new LinearLayout(this);con.setPadding(0,10,0,10);con.setGravity(Gravity.CENTER_VERTICAL);
        ip=new EditText(this);ip.setHint("Game phone IP (e.g. 192.168.43.1)");ip.setTextColor(Color.WHITE);ip.setHintTextColor(Color.GRAY);ip.setSingleLine();con.addView(ip,new LinearLayout.LayoutParams(0,Wrap(55),1));
        Button c=btn("CONNECT");c.setOnClickListener(v->connect());con.addView(c,new LinearLayout.LayoutParams(Wrap(115),Wrap(55)));list.addView(con);
        TextView info=tv("Player Dice Overrides  •  Tap a number to set it",18);info.setTextColor(Color.rgb(150,235,170));info.setPadding(4,20,4,12);list.addView(info);
        for(int p=1;p<=4;p++) addPlayer(p,colors[p-1]);
        Button game=btn("Open QA Game Receiver");game.setOnClickListener(v->showReceiver());list.addView(game,new LinearLayout.LayoutParams(-1,Wrap(58)));
    }
    void addPlayer(int p,String color){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(10,10,10,14);box.setBackground(bg(card,20));
        TextView title=tv("Player "+p+" ("+color+")",18);box.addView(title);
        LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL); final TextView chosen=tv("—",22);chosen.setGravity(Gravity.CENTER);chosen.setBackground(bg(Color.rgb(55,66,82),16));row.addView(chosen,new LinearLayout.LayoutParams(0,Wrap(48),1));box.addView(row,new LinearLayout.LayoutParams(-1,Wrap(56)));
        LinearLayout nums=new LinearLayout(this);nums.setPadding(0,6,0,0); for(int n=1;n<=6;n++){final int val=n;Button b=btn(""+n);b.setOnClickListener(v->{chosen.setText("SET: "+val);send(p,val);});nums.addView(b,new LinearLayout.LayoutParams(0,Wrap(52),1));} Button rnd=btn("RND");rnd.setOnClickListener(v->{int val=1+(int)(Math.random()*6);chosen.setText("RND: "+val);send(p,val);});nums.addView(rnd,new LinearLayout.LayoutParams(0,Wrap(52),1));box.addView(nums);list.addView(box,new LinearLayout.LayoutParams(-1,Wrap(150)));
    }
    void connect(){String host=ip.getText().toString().trim();if(host.isEmpty()){toast("Enter the game phone IP");return;}pool.execute(()->{try{socket=new Socket();socket.connect(new InetSocketAddress(host,5050),2500);out=new PrintWriter(new BufferedWriter(new OutputStreamWriter(socket.getOutputStream())),true);runOnUiThread(()->{status.setText("●  CONNECTED");status.setTextColor(Color.rgb(80,235,115));});}catch(Exception e){runOnUiThread(()->toast("Connection failed: "+e.getMessage()));}});}
    void send(int p,int n){JSONObject o=new JSONObject();try{o.put("player",p);o.put("dice",n);o.put("ts",System.currentTimeMillis());}catch(Exception ignored){} String msg=o.toString(); if(out!=null){pool.execute(()->out.println(msg));} else if(receiver){handle(msg);} else toast("Connect to a QA Game receiver first");}
    void showReceiver(){receiver=true;base("Ludo QA Game • Receiver"); TextView s=tv("Listening on TCP port 5050",17);s.setTextColor(Color.rgb(150,235,170));list.addView(s);Button start=btn("START RECEIVER");list.addView(start);TextView dice=tv("Waiting for dice…",32);dice.setGravity(Gravity.CENTER);dice.setBackground(bg(card,22));list.addView(dice,new LinearLayout.LayoutParams(-1,Wrap(100)));start.setOnClickListener(v->startServer(dice));Button back=btn("Back to Controller");back.setOnClickListener(v->showController());list.addView(back);}
    void startServer(TextView dice){pool.execute(()->{try{ServerSocket ss=new ServerSocket(5050);runOnUiThread(()->toast("Receiver started"));while(true){Socket s=ss.accept();BufferedReader r=new BufferedReader(new InputStreamReader(s.getInputStream()));String line;while((line=r.readLine())!=null){final String x=line;runOnUiThread(()->{try{JSONObject o=new JSONObject(x);dice.setText("PLAYER "+o.getInt("player")+"  →  DICE "+o.getInt("dice"));}catch(Exception ignored){}});}}}catch(Exception e){runOnUiThread(()->toast("Receiver error: "+e.getMessage()));}});}
    void handle(String msg){ }
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
    @Override protected void onDestroy(){super.onDestroy();try{if(socket!=null)socket.close();}catch(Exception ignored){}pool.shutdownNow();}
}
